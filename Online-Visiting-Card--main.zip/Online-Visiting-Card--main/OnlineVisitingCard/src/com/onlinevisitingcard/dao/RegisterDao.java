package com.onlinevisitingcard.dao;

import com.onlinevisitingcard.entity.Register;

public interface RegisterDao {
	boolean save(Register r);

}
