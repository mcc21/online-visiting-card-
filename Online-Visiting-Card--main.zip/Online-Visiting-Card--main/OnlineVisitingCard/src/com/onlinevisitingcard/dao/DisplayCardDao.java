package com.onlinevisitingcard.dao;

import java.util.List;
import com.onlinevisitingcard.entity.DisplayCard;
public interface DisplayCardDao {
	List<DisplayCard> get();
 
}
