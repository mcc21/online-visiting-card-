package com.onlinevisitingcard.dao;

import com.onlinevisitingcard.entity.*;

public interface EnterCustomerDetailsDao {
	
	boolean save(EnterCustomerDetails e);
}
