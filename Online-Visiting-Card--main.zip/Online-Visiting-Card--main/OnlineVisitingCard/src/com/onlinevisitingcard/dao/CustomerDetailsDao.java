package com.onlinevisitingcard.dao;

import java.util.List;

import com.onlinevisitingcard.entity.CustomerDetails;

public interface CustomerDetailsDao {
	List<CustomerDetails> get();
}
